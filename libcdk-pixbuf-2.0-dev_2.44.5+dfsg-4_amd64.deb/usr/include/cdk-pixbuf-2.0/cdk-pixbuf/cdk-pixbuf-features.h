#ifndef __CDK_PIXBUF_FEATURES_H__
#define __CDK_PIXBUF_FEATURES_H__

#if defined(CDK_PIXBUF_DISABLE_SINGLE_INCLUDES) && !defined (CDK_PIXBUF_H_INSIDE) && !defined (CDK_PIXBUF_COMPILATION)
#error "Only <cdk-pixbuf/cdk-pixbuf.h> can be included directly."
#endif

#include <glib.h>

/**
 * CDK_PIXBUF_MAJOR:
 * 
 * Major version of cdk-pixbuf library, that is the "0" in
 * "0.8.2" for example.
 */
/**
 * CDK_PIXBUF_MINOR:
 * 
 * Minor version of cdk-pixbuf library, that is the "8" in
 * "0.8.2" for example.
 */
/**
 * CDK_PIXBUF_MICRO:
 * 
 * Micro version of cdk-pixbuf library, that is the "2" in
 * "0.8.2" for example.
 */
/**
 * CDK_PIXBUF_VERSION:
 * 
 * Contains the full version of CdkPixbuf as a string.
 *
 * This is the version being compiled against; contrast with
 * `cdk_pixbuf_version`.
 */

#define CDK_PIXBUF_MAJOR (2)
#define CDK_PIXBUF_MINOR (44)
#define CDK_PIXBUF_MICRO (5)
#define CDK_PIXBUF_VERSION "2.44.5"

#ifndef _CDK_PIXBUF_EXTERN
#define _CDK_PIXBUF_EXTERN extern
#endif

/* We prefix variable declarations so they can
 * properly get exported/imported from Windows DLLs.
 */
#ifdef G_PLATFORM_WIN32
#  ifdef CDK_PIXBUF_STATIC_COMPILATION
#    define CDK_PIXBUF_VAR extern
#  else /* !CDK_PIXBUF_STATIC_COMPILATION */
#    ifdef CDK_PIXBUF_C_COMPILATION
#      ifdef DLL_EXPORT
#        define CDK_PIXBUF_VAR _CDK_PIXBUF_EXTERN
#      else /* !DLL_EXPORT */
#        define CDK_PIXBUF_VAR extern
#      endif /* !DLL_EXPORT */
#    else /* !CDK_PIXBUF_C_COMPILATION */
#      define CDK_PIXBUF_VAR extern __declspec(dllimport)
#    endif /* !CDK_PIXBUF_C_COMPILATION */
#  endif /* !CDK_PIXBUF_STATIC_COMPILATION */
#else /* !G_PLATFORM_WIN32 */
#  define CDK_PIXBUF_VAR _CDK_PIXBUF_EXTERN
#endif /* !G_PLATFORM_WIN32 */

/**
 * cdk_pixbuf_major_version:
 * 
 * The major version number of the cdk-pixbuf library.  (e.g. in 
 * cdk-pixbuf version 1.2.5 this is 1.) 
 * 
 * 
 * This variable is in the library, so represents the
 * cdk-pixbuf library you have linked against. Contrast with the
 * `CDK_PIXBUF_MAJOR` macro, which represents the major version of the
 * cdk-pixbuf headers you have included.
 */
/**
 * cdk_pixbuf_minor_version:
 * 
 * The minor version number of the cdk-pixbuf library.  (e.g. in 
 * cdk-pixbuf version 1.2.5 this is 2.) 
 * 
 * 
 * This variable is in the library, so represents the
 * cdk-pixbuf library you have linked against. Contrast with the
 * `CDK_PIXBUF_MINOR` macro, which represents the minor version of the
 * cdk-pixbuf headers you have included.
 */
/**
 * cdk_pixbuf_micro_version:
 * 
 * The micro version number of the cdk-pixbuf library.  (e.g. in 
 * cdk-pixbuf version 1.2.5 this is 5.) 
 * 
 * 
 * This variable is in the library, so represents the
 * cdk-pixbuf library you have linked against. Contrast with the
 * `CDK_PIXBUF_MICRO` macro, which represents the micro version of the
 * cdk-pixbuf headers you have included.
 */
/**
 * cdk_pixbuf_version:
 * 
 * Contains the full version of the cdk-pixbuf library as a string.
 * This is the version currently in use by a running program.
 */

CDK_PIXBUF_VAR const guint cdk_pixbuf_major_version;
CDK_PIXBUF_VAR const guint cdk_pixbuf_minor_version;
CDK_PIXBUF_VAR const guint cdk_pixbuf_micro_version;
CDK_PIXBUF_VAR const char *cdk_pixbuf_version;

#endif /* __CDK_PIXBUF_FEATURES_H__ */
